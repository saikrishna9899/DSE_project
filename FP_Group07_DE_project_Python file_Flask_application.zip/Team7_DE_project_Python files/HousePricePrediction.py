import pandas as pd
import snowflake.connector
conn_params = {
    'account': 'osa14176.east-us-2.azure',
    'user': 'saikrishna',
    'password': 'Sai@9490984187',
    'warehouse': 'COMPUTE_WH',
    'database': 'DE_SAMPLE_DB',
    'schema': 'DEV'
}

# Establish a connection
conn = snowflake.connector.connect(**conn_params)

import dask.dataframe as dd
cursor = conn.cursor()

# Define the SQL query
query = "SELECT * FROM Apartment"  # Replace with your Snowflake table name

# Execute the query and fetch the data
sales = pd.read_sql(query, conn)

#print(sales)
# Close the Snowflake connection
#conn.close()


sale_year = sales["SALEDATE_YEAR"].astype(int)
sale_month = sales["SALEDATE_MONTH"].astype(int)
sale_day = sales["SALEDATE_DAY"].astype(int)

#print(sale_day)

month_names = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
sales["sale_named_month"] = sale_month.map(lambda x: month_names[x-1])

#print(sales["sale_named_month"])

sales["sale_named_month"] = pd.Categorical(sales["sale_named_month"], categories = month_names, ordered = True)

sales["sale_named_month"].head()


# Create a boolean variable for if the property sold for a price over $)
sales.insert(sales.columns.get_loc("PRICE")+1, "with_prices", sales["PRICE"].apply(lambda x: False if x == 0 else True))

# Create a boolean for if the property was remodeled
sales.insert(sales.columns.get_loc("YR_RMDL")+1, "remodeled", sales["YR_RMDL"].notnull())


import pandas as pd

# Assuming "SALEDATE" is the column containing date values
sales["SALEDATE"] = pd.to_datetime(sales["SALEDATE"])

# Now you can perform datetime operations on the "SALEDATE" column
def year_diff(a, b):
    return (a.dt.year - b.year)

def month_diff(a, b):
    return 12 * (a.dt.year - b.year) + (a.dt.month - b.month)

sales["num_years_passed"] = year_diff(sales["SALEDATE"], pd.Timestamp("2010/01/01 00:00:00+00"))
sales["num_months_passed"] = month_diff(sales["SALEDATE"], pd.Timestamp("2010/01/01 00:00:00+00"))
sales["num_days_passed"] = (sales["SALEDATE"] - pd.Timestamp("2010/01/01 00:00:00+00")).dt.days


#print(sale_year.value_counts())


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
year_graph_data = sale_year.value_counts().rename_axis(["sale_year"]).reset_index(name = "count")

year_graph = sns.barplot(data = year_graph_data, x = "sale_year", y = "count", color = "steelblue")
year_graph.set(title = "Number of Sales by Year", xlabel = "Year")
year_graph.set_xticks(range(0, 69, 5))
#plt.show()

# Assuming 'sales' is your original DataFrame
# Assuming 'sale_year' is a column in the 'sales' DataFrame

# Apply the conditions to filter the DataFrame
sales_trimmed = sales[(sale_year >= 2010) & (sale_year < 2023) & sales["PRICE"].notnull()]

# Number of rows in your subset missing sale price
#print(len(sales_trimmed))

# We can add more variables if we identify more unneeded variables
cols_to_drop = ["SSL", "GIS_LAST_MOD_DTTM", "OBJECTID"]

# Drop the specified columns
sales_trimmed = sales_trimmed.drop(cols_to_drop, axis=1)
#print(sales_trimmed)


#%%
### EDA

#%%
#print(sales_trimmed.shape)
#print(sales_trimmed.info())
# For this it makes sense to only use sales where the property sold for a price, not for $0
sales_trimmed_with_price = sales_trimmed[sales_trimmed["with_prices"] == True]

#print(sales_trimmed_with_price)


from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Drop rows with missing values
sales_trimmed_with_price = sales_trimmed_with_price.dropna()

##  Adding num_days_passed as predictor to the model: 

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    sales_trimmed_with_price[['BATHRM', 'BEDRM', 'GRADE', 'HEAT', 'CNDTN', 'GBA', 'num_days_passed']],
    sales_trimmed_with_price['PRICE'],
    test_size=0.2,
    random_state=42
)

# Instantiate the linear regression model
fit5 = LinearRegression()

# Fit the model to the training data
fit5.fit(X_train, y_train)

# Make predictions on the test data
y_pred = fit5.predict(X_test)

# Evaluate the model's performance
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

#print("Mean squared error:", mse)
#print("R-squared:", r2)

# Print the coefficients of the model
#print("Coefficients:", fit5.coef_)



from flask import Flask, render_template, request, jsonify
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np

app = Flask(__name__)

# Assuming fit5 is your trained linear regression model
# You should load your model here
X_train, X_test, y_train, y_test = train_test_split(
    sales_trimmed_with_price[['BATHRM', 'BEDRM', 'GRADE', 'HEAT', 'CNDTN', 'GBA', 'num_days_passed']],
    sales_trimmed_with_price['PRICE'],
    test_size=0.2,
    random_state=42
)

# Instantiate the linear regression model
fit5 = LinearRegression()

# Fit the model to the training data
fit5.fit(X_train, y_train)

# Make predictions on the test data
y_pred = fit5.predict(X_test)

feature_names=['BATHRM', 'BEDRM', 'GRADE', 'HEAT', 'CNDTN', 'GBA', 'num_days_passed']
# Define the route for the home page
@app.route('/')
def home():
    return render_template('index.html')  # Create an HTML file for your home page

# Define an endpoint for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get input features from the request
    input_data = request.form.to_dict()

    # Convert the input data to a 2D array
    input_array = np.array([float(input_data[feature]) for feature in feature_names]).reshape(1, -1)

    # Use the model to make predictions
    prediction = fit5.predict(input_array)
    print(prediction)

    # Return the prediction as a rendered HTML page
    return render_template('result.html', prediction=prediction[0])

if __name__ == '__main__':
    app.run(debug=False)
